#include "server_base.h"
#include "GPB.h"
#include "protocal/amazon.pb.h"
#include <string>
#include <iostream>

const char* sim_IP = "10.236.48.17";
const char* PORT = "23456";
 
int main(int argc, char* argv[]){

  /*  create database conncection */
  // connection* C = create_connection();
  //create_tables(C);

  /*  connect socket to sim */
  int sockfd, numbytes;  
  struct addrinfo hints, *servinfo, *p;
  int rv;
  char s[INET6_ADDRSTRLEN];
  set_hints(&hints);
  get_addr_info(&hints, &servinfo, &rv, PORT, sim_IP);  
  connect_sock(&servinfo, &sockfd,  s);

  /* google protoco buffer */
  /* write connect message */
  AInitWarehouse* initWh = new AInitWarehouse();
  initWh->set_x(13);
  initWh->set_y(16);
  AConnect* conn = new AConnect();
  conn->set_worldid(1);
  conn->set_allocated_initwh(initWh);
  //std::string* output = new std::string();
  //conn.SerializeToString(output);
  google::protobuf::io::FileOutputStream * outfile = new google::protobuf::io::FileOutputStream(sockfd);
  sendMesgTo(*conn, outfile);
  
  /* test */
  /*
  AConnect connTest;
  connTest.ParseFromString(*output);
  printf("worldid = %lu\n", connTest.worldid());
  */

  
  /*Delete all global objects allocated by libprotobuf */
  google::protobuf::ShutdownProtobufLibrary();
  
  return 0;
}
