#include "server_base.h"
const char* sim_IP = "10.236.48.17";
const char* PORT = "23456";
 
int main(int argc, char* argv[]){

  /* ## create database conncection */
  // connection* C = create_connection();
  //create_tables(C);

  /* ## send connect to sim as client */
  int sockfd, numbytes;  
  struct addrinfo hints, *servinfo, *p;
  int rv;
  char s[INET6_ADDRSTRLEN];
  
  /* socket */
  set_hints(&hints);

  /* form connect message */
  
  /* send it to sim */
  get_addr_info(&hints, &servinfo, &rv, PORT, sim_IP);  
  connect_sock(&servinfo, &sockfd,  s);
}
